import { Injectable } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DbService {

  usuarioValido: string = 'admin';
  passValido: string = 'admin';
  validator: boolean = false;

  constructor(private router: Router) { }

  canActivate(){
    if(this.validator){
      return true
    }else{
      this.router.navigate(['login']);
      return false
    };
  }
  autenticator(mdlusuario, mdlpass){
    let extras: NavigationExtras= {
      state:{
        mdlusuario: mdlusuario, 
        message: 'Bienvenido '
      }
    }
    if(mdlusuario == this.usuarioValido && mdlpass == this.passValido){
      this.validator = true;
      this.router.navigate(['principal'], extras);
      return true;
    }else{
      return false;
    }

  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-principal',
  templateUrl: './principal.page.html',
  styleUrls: ['./principal.page.scss'],
})
export class PrincipalPage implements OnInit {

  modeloUsuario: string = '';
  message: string = '';

  constructor(private router: Router) { }

  ngOnInit() {
    this.modeloUsuario = this.router.getCurrentNavigation().extras.state.mdlusuario;
    console.log(this.modeloUsuario);
    this.message = this.router.getCurrentNavigation().extras.state.message;
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { DbService } from 'src/app/services/db.service';

@Component({
  selector: 'app-contrasena',
  templateUrl: './contrasena.page.html',
  styleUrls: ['./contrasena.page.scss'],
})
export class ContrasenaPage implements OnInit {
  modeloUsuario: string = '';
  modeloContrasena: string = '';
  modeloContrasena2: string = '';

  constructor(private router: Router, private alertController: AlertController, private db: DbService) { }

  ngOnInit() {
  }

  changePass(){
    if(this.modeloUsuario == '' || this.modeloContrasena == ''|| this.modeloContrasena2 == ''){
      console.log('campos vacios');
    }else{
      if(this.modeloUsuario == this.db.usuarioValido && this.modeloContrasena == this.db.passValido){
        if(this.modeloContrasena != this.modeloContrasena2){
          this.db.passValido = this.modeloContrasena2;
          console.log('Contraseña cambiada');
          this.router.navigate(['login']);
          this.removeData();
        }else{
          console.log('No puede ser la misma que la anterior');
          this.removeData();
        }
        }else{
        console.log("credencial invalida");
        this.removeData();
      }
    };
  }
  removeData(){
    this.modeloUsuario = '';
    this.modeloContrasena = '';
    this.modeloContrasena2 = '';
  }
}


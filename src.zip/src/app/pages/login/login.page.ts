import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { DbService } from 'src/app/services/db.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  modeloUsuario = '';
  modeloContrasena = '';

  constructor(private db: DbService, private alertController: AlertController) {
    console.log('Pagina login iniciada');
    
  }

  ngOnInit() {
    console.log(this.db.passValido);
  }
  validarCredenciales(){
    if(!this.db.autenticator(this.modeloUsuario, this.modeloContrasena)){
      this.presentAlert();
    };
    this.modeloUsuario= '';
    this.modeloContrasena= '';
  }
  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Error',
      message: 'Credencial incorrecta',
      buttons: ['Aceptar'],
    });
    await alert.present();
  }
}
